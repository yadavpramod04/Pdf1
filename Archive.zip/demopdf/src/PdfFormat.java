import java.io.FileOutputStream;
import java.util.Date;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
//import com.itextpdf.layout.properties.TextAlignment;

public class PdfFormat {
    public static String FILE = "C:\\Users\\BARC\\Documents\\NetBeansProjects\\pdfformat\\FirstPdf.pdf";
    private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18,
            Font.BOLD);
    private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,
            Font.NORMAL, BaseColor.RED);
    private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 16,
            Font.BOLD);
    private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12,
            Font.BOLD);
   
    public static void main(String[] args) {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(FILE));
            document.open();      
            addMetaData(document);
            //addTitlePage(document);
            addContent(document);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // iText allows to add metadata to the PDF which can be viewed in your Adobe
    // Reader
    // under File -> Properties
    private static void addMetaData(Document document) {
        document.addTitle("My first PDF");
        document.addSubject("Using iText");
        document.addKeywords("Java, PDF, iText");
        document.addAuthor("Lars Vogel");
        document.addCreator("Lars Vogel");
    }
    
    public static void addContent(Document document) throws DocumentException {
        Anchor anchor = new Anchor("First Chapter_AAAA", catFont);
        anchor.setName("First Chapter");
         
        // First parameter is the number of the chapter
        Chapter catPart = new Chapter(new Paragraph(anchor), 1);

        Paragraph subPara = new Paragraph("Subcategory 1_bbbb", subFont);
        Section subCatPart = catPart.addSection(subPara);
        Paragraph objdd=new Paragraph("Hello");
        objdd.setAlignment(2);
        subCatPart.add((objdd));
        
        // add a list
        createList(subCatPart);
        Paragraph paragraph = new Paragraph();
        addEmptyLine(paragraph, 5);
        subCatPart.add(paragraph);
        

        // add a table
        createTable(subCatPart);

        // now add all this to the document
        document.add(catPart);
/****************************************************/
        // Next section
        anchor = new Anchor("Second Chapter", catFont);
        anchor.setName("Second Chapter");
        

        // Second parameter is the number of the chapter
        Chapter catPart1 = new Chapter(new Paragraph(anchor), 2);
        
        Paragraph subPara1 = new Paragraph("Subcategory", subFont);
        Section subdatpart = catPart1.addSection(subPara1);
        Paragraph objd = new Paragraph("subcategory 2.1");
        objd.setAlignment(2);
        subdatpart.add(objd);  
        // now add all this to the document
          // add a list
        createList(subdatpart);
        Paragraph paragraph1 = new Paragraph();
        addEmptyLine(paragraph1, 7);
        subdatpart.add(paragraph1);
             

        // add a table
        createTable(subdatpart);
        // now add all this to the document
        document.add(catPart1);
        subPara.setAlignment(2);
        document.add(subPara);

    }
    
     private static void createTable(Section subCatPart)
            throws BadElementException {
        PdfPTable table = new PdfPTable(8);
         
        PdfPCell c1 = new PdfPCell(new Phrase("Unit Id"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);

        c1 = new PdfPCell(new Phrase("Location"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);

        c1 = new PdfPCell(new Phrase("Avg"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        
        c1 = new PdfPCell(new Phrase("Max"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        
        c1 = new PdfPCell(new Phrase("Alarm Generated"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        
        c1 = new PdfPCell(new Phrase("Alddd"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        
        c1 = new PdfPCell(new Phrase("ffff"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        
        c1 = new PdfPCell(new Phrase("gggg"));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        

        table.setHeaderRows(4);
        for(int i=0;i<4;i++)
        {
        table.addCell("1.0");
        table.addCell("1.1");
        table.addCell("1.2");
        table.addCell("2.1");
        table.addCell("2.2");
        table.addCell("2.1");
        table.addCell("2.2");
        table.addCell("2.2");
        }
       // table.addCell("PDG");
      
        subCatPart.add(table);
        //subCatPart.add(table);

     }
      private static void createList(Section subCatPart) {
        List list = new List(true, false, 10);
        list.add(new ListItem("First point"));
        list.add(new ListItem("Second point"));
        list.add(new ListItem("Third point"));
        
        subCatPart.add(list);
    }
    

    
   
        
     
    private static void addEmptyLine(Paragraph paragraph, int number) {
        for (int i = 0; i < number; i++) {
            paragraph.add(new Paragraph(""));
        }   
    }
}
