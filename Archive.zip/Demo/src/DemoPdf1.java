import java.io.FileOutputStream;
import java.util.Date;

import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.Element;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
//import com.itextpdf.layout.properties.TextAlignment;

public class DemoPdf1 {
    public static String FILE = "C:\\Users\\BARC\\Documents\\NetBeansProjects\\Demo\\FirstPdf.pdf";
    private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,
            Font.BOLD);
    private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,
            Font.BOLD, BaseColor.RED);
    private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,
            Font.BOLD);
    private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 9,
            Font.BOLD);
    private static Font fFont = new Font(Font.FontFamily.TIMES_ROMAN, 9,
            Font.BOLD);
    private static Font XsmallFont = new Font(Font.FontFamily.TIMES_ROMAN, 9,
            Font.NORMAL);
    private static Font font = new Font(Font.FontFamily.TIMES_ROMAN, 9,
            Font.NORMAL);
    private static Font font12Norm = new Font(Font.FontFamily.TIMES_ROMAN, 12,
            Font.NORMAL);
    private static Font font12Norm1 = new Font(Font.FontFamily.TIMES_ROMAN, 10,
            Font.NORMAL);
    
   
    public static void main(String[] args) {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(FILE));
            document.open();
      
//            addMetaData(document);
//            addTitlePage(document);
            addContent(document);                               
            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void addContent(Document document) throws DocumentException {
         
        Paragraph ICCM_PARAA = new Paragraph("*** This is REWS System Generated Report ***", XsmallFont);
        ICCM_PARAA.setAlignment (1);
        document.add(ICCM_PARAA);
  
        
        Paragraph ICCM_PARA = new Paragraph("ICCM SHIFT REPORT", subFont);
        ICCM_PARA.setAlignment(1);
        document.add(ICCM_PARA);
        
        
       
       
        
        Paragraph ICCM_PARA_Title = new Paragraph("Radiation Early Warning System", subFont);
        ICCM_PARA_Title.setAlignment(1);
        document.add(ICCM_PARA_Title);
        
       
        Paragraph objdda=new Paragraph("Date:-27/05/2022",smallBold);
        Paragraph objddb=new Paragraph("Time:-12:30PM",smallBold);
        Paragraph objddc=new Paragraph("Shift:-I/II/III",smallBold);
        
        
        objdda.setFirstLineIndent(445);
        document.add(objdda);
        
        objddb.setFirstLineIndent(445);
        document.add(objddb);
        
        objddc.setFirstLineIndent(445);
        document.add(objddc);
        
        Paragraph objddc1=new Paragraph("Reactor Status:-",smallBold);
        objddc1.setFirstLineIndent(445);
        document.add(objddc1);
        
        Paragraph objdda2=new Paragraph("1)Dhruva:-(MW(t))",smallBold);
        objdda2.setFirstLineIndent(440);
        objdda2.setAlignment(0);
        document.add(objdda2);
        
        Paragraph objdda3=new Paragraph("2)Apsara:-(MW(t))",smallBold);
        objdda3.setFirstLineIndent(440);
        objdda3.setAlignment(0);
        document.add(objdda3);
        
        

       
        Paragraph ICCM_PARA_Head = new Paragraph("REWS Status Report:-", subFont);
        ICCM_PARA_Head.setAlignment(0);
        document.add(ICCM_PARA_Head);
      
        Paragraph EmptyPara = new Paragraph();
        addEmptyLine(EmptyPara, 1);
        
        //PdfPTable tableICCM = new PdfPTable(5);
        //tableICCM=createTableICCM();
   
         document.add(EmptyPara);      
         document.add(createTableICCM());
        
      //------------------------------------------------------------------------------------------------- //

   
        
        ICCM_PARA_Title = new Paragraph("Radiation Early Warning System", subFont);
        ICCM_PARA_Title.setAlignment(1);
        
        
       
      
        addEmptyLine(EmptyPara, 2);
        Paragraph ICCM_PARAFULLTPA = new Paragraph("Weather Status at BARC,Mumbai:-",subFont);  
        document.add(EmptyPara);
        ICCM_PARAFULLTPA.setAlignment(0);
            
        document.add(ICCM_PARAFULLTPA);
        document.add(EmptyPara);
    
        
        document.add(createTableICCM3());
        
        Paragraph ICCM_PARAFULL = new Paragraph("BARC Site Rews Status :-",subFont);
        ICCM_PARAFULL.setAlignment(0);
        document.add(ICCM_PARAFULL);
        
        Paragraph objdda1=new Paragraph("1)Average Dose Rate:-(ngy/h)",smallBold);
        objdda1.setFirstLineIndent(125);
        objdda1.setAlignment(0);
        document.add(objdda1);
        
        Paragraph objddb2=new Paragraph("2)Max Dose Rate:-1 2 3(ngy/h)",smallBold); 
        objddb2.setFirstLineIndent(125);
        objddb2.setAlignment(0);
        document.add(objddb2);
        
        
        Paragraph ICCM_PARAFULLT = new Paragraph("Total Alarm Generated :-",subFont);
        document.add(ICCM_PARAFULLT);
        
        Paragraph ICCM_PARAFULLTP = new Paragraph("Total Alarm Ack :-",subFont );
        ICCM_PARAFULLTP.setAlignment(0);
        document.add(ICCM_PARAFULLTP);
        ICCM_PARAFULLTP.setAlignment(0);
       
        
       
        
      
       
        
       
        
        
        
        document.setPageSize(PageSize.A4.rotate());
        document.newPage();
       
       
        
        Paragraph ICCM_PARA_Alarm_Head = new Paragraph("REWS Alarm Report:-", subFont);
        ICCM_PARA_Alarm_Head.setAlignment(0); 
        
        EmptyPara = new Paragraph();
        addEmptyLine(EmptyPara, 1);
        document.add(ICCM_PARA_Alarm_Head);
        
        document.add(EmptyPara);
        
        document.add(createTableICCM2());
   
      
        EmptyPara = new Paragraph();
        addEmptyLine(EmptyPara, 1);
        
        Paragraph ICCM_PARAA1 = new Paragraph("*** This is REWS System Generated Report ***", XsmallFont);
        ICCM_PARAA1.setAlignment(1);
        document.add(ICCM_PARAA1);
    
        
      
        
        
        //third table
  
         
    }
     
    private static PdfPTable createTableICCM()
            {
        PdfPTable table = new PdfPTable(5);
     
         
        PdfPCell c1 = new PdfPCell(new Phrase("Unit Id",smallBold));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
//        c1.setWidthPercentage(10);
        try {
            
            table.setWidths(new int[]{50,200,100,100,100});
            
        } catch (DocumentException ex) {
            Logger.getLogger(DemoPdf1.class.getName()).log(Level.SEVERE, null, ex);
        }
//        table.setWidths(new int[]{100,150,200,100,50});
        table.addCell(c1);
  
 

        c1 = new PdfPCell(new Phrase("Location",smallBold));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);

        c1 = new PdfPCell(new Phrase("Avg",smallBold));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        
        c1 = new PdfPCell(new Phrase("Max",smallBold));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
        
        c1 = new PdfPCell(new Phrase("Alarm Generated",smallBold));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c1);
  
    //    table.setHeaderRows(5);
          for(int i=1;i<=40;i++)
               
          {  
            c1 = new PdfPCell(new Phrase(Integer.toString(i),font12Norm1));
            c1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c1);
            
            
            c1 = new PdfPCell(new Phrase("2",font12Norm1));
            c1.setHorizontalAlignment(Element.ALIGN_CENTER);
            c1.setFixedHeight(8);
            table.addCell(c1); 
        
       
            c1 = new PdfPCell(new Phrase("3",font12Norm1));
            c1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c1); 

            c1 = new PdfPCell(new Phrase("4",font12Norm1));
            c1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c1); 
    
            c1 = new PdfPCell(new Phrase("5",font12Norm1));
            c1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c1);          
        }
        
      return table;
    }
    
    
      private static PdfPTable createTableICCM2()
            {
        PdfPTable table = new PdfPTable(10);
        
        PdfPCell c2 = new PdfPCell(new Phrase("Sr No",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        

        c2 = new PdfPCell(new Phrase("Location",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
      

        c2 = new PdfPCell(new Phrase("Duration(min)",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        
        c2 = new PdfPCell(new Phrase("Max(ngy/hr)",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        
        c2 = new PdfPCell(new Phrase("Generated At",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        
        c2 = new PdfPCell(new Phrase("Avg wind speed(m/s)",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        
        c2 = new PdfPCell(new Phrase("Avg wind direction(sector)",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        
     
        c2 = new PdfPCell(new Phrase("Acknowledge At",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        
        c2 = new PdfPCell(new Phrase("Acknowledge By",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        
        c2 = new PdfPCell(new Phrase("Remark",smallBold));
        c2.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(c2);
        

      //  table.setHeaderRows(5);

          for(int i=1;i<=11;i++)
               
          {  
              try {
            
            table.setWidths(new int[]{25,100,25,50,70,50,50,70,60,100});
            
        } catch (DocumentException ex) {
            Logger.getLogger(DemoPdf1.class.getName()).log(Level.SEVERE, null, ex);
        }
            c2 = new PdfPCell(new Phrase(Integer.toString(i),font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
            
            c2 = new PdfPCell(new Phrase("2",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
            
            c2 = new PdfPCell(new Phrase("3",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
           
            c2 = new PdfPCell(new Phrase("4",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
           
            c2 = new PdfPCell(new Phrase("5",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
             
            c2 = new PdfPCell(new Phrase("6 ",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
         
            c2 = new PdfPCell(new Phrase("7",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
          
            c2 = new PdfPCell(new Phrase("8",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
          
            c2 = new PdfPCell(new Phrase("9",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
            
            c2 = new PdfPCell(new Phrase("10",font12Norm1));
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c2);
            
          }
       return(table); 
      }
    
      
      
       private static PdfPTable createTableICCM3()
             {
        PdfPTable table3 = new PdfPTable(3);
        
        String WeatherData []={"Wind Speed(m/s)","Temprature(oC)","Humidity(% RH)","Solar Radiation(web/m2)","Prodiment Wind Direction(Sector)"};
        
        PdfPCell c1 = new PdfPCell(new Phrase("   "));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table3.addCell(c1);
        
        c1 = new PdfPCell(new Phrase(" Min ",smallBold));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table3.addCell(c1);
        
        
        
        c1 = new PdfPCell(new Phrase(" Max ",smallBold));
        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        table3.addCell(c1);
        
        
        
        
//        c1 = new PdfPCell(new Phrase(" ",font12Norm));
//        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
        
       
        
        
        for(int i=0;i<5;i++)
          {
              
           table3.addCell(WeatherData[i]);
           
           c1 = new PdfPCell(new Phrase("2",font12Norm));
           c1.setHorizontalAlignment(Element.ALIGN_CENTER);
           table3.addCell(c1); 
           
           c1 = new PdfPCell(new Phrase("3",font12Norm));
           c1.setHorizontalAlignment(Element.ALIGN_CENTER);
           table3.addCell(c1);
          }
        
      return table3;
    }
   
       private static void createList(Section subCatPart) {
           
        List list = new List(true, false, 10);
        
        list.add(new ListItem("REWS Status Report"));
//        list.add(new ListItem("Max:-REWS Staus Report"));
//        list.add(new ListItem("Third point"));
        subCatPart.add(list);  
      }
    private static void addEmptyLine(Paragraph paragraph, int number) {
        for (int i = 0; i < number; i++) {
            paragraph.add(new Paragraph(""));
        }  
    }
}